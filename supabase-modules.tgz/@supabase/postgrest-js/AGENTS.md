# Agent instructions for `@supabase/postgrest-js`

Isomorphic PostgREST client for database operations (select, insert, update, upsert, delete, filters, RPC).

When helping a user work with this package:

- **Usage and quick start**: [`README.md`](./README.md)
- **Full API reference**: [`src/`](./src/) — every public method and type has TSDoc with `@example` blocks. Read the source for the canonical, version-pinned answer.
- **Migration notes**: [`migrations/`](./migrations/) — per-theme markdown files for changes that need caller action.

For broader Supabase guidance (docs site, MCP tools, schema and project workflows), use the centralized [Supabase agent skills](https://github.com/supabase/agent-skills): `npx skills add supabase/agent-skills`. Or pair with the Supabase MCP server via the [Supabase Plugin for AI Coding Agents](https://supabase.com/docs/guides/getting-started/plugins).
